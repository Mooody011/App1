export default function Home() {
  return (
    <div className="min-h-screen bg-[#0B0C10] flex items-center justify-center p-4">
      <div className="max-w-3xl w-full bg-[#1C1E27] text-white rounded-xl p-8 md:p-12 shadow-xl shadow-black/10 hover:shadow-lg transition-shadow duration-300">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">
          Welcome to Our Platform
        </h1>
        <p className="text-lg md:text-xl mb-8">
          Experience seamless connectivity and powerful insights. Join us to transform the way you work and collaborate.
        </p>
        <div className="flex space-x-4">
          <button className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-violet-600 rounded-full text-white font-semibold hover:from-indigo-700 hover:to-violet-700 transition-all duration-200">
            Log In
          </button>
          <a href="/signup" className="px-6 py-3 border-2 border-white rounded-full text-white font-semibold hover:bg-white hover:text-[#0B0C10] transition-all duration-200">
            Sign Up
          </a>
        </div>
      </div>
    </div>
  );
}