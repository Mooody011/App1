export default function Dashboard() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 text-white p-12">
      <h1 className="text-4xl font-bold mb-4">Dashboard</h1>
      <p className="text-lg text-slate-200">Overview of user profile, cloned apps, and usage statistics</p>
    </div>
  );
}