export default function Clone() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 text-white p-12">
      <h1 className="text-4xl font-bold mb-4">Clone</h1>
      <p className="text-lg text-slate-200">Form to select an app to clone and set hide preferences</p>
    </div>
  );
}