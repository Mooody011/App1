// server/api.js
const express = require('express')
const jwt = require('jsonwebtoken')
const bcrypt = require('bcryptjs')

const router = express.Router()

// ---------------------------------------------------------------------------
// Mock database
// ---------------------------------------------------------------------------
let users = []          // [{ id, email, passwordHash, role }]
let cloneRecords = []   // [{ id, userId, originalPackage, clonePackage, isHidden, createdAt }]

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
const generateId = () => Math.random().toString(36).substr(2, 9)
const JWT_SECRET = 'supersecretkey'   // in production use env variable

// ---------------------------------------------------------------------------
// Authentication middleware
// ---------------------------------------------------------------------------
function authenticate(req, res, next) {
  const auth = req.headers.authorization
  if (!auth || !auth.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Missing token' })
  }
  const token = auth.split(' ')[1]
  try {
    const payload = jwt.verify(token, JWT_SECRET)
    const user = users.find(u => u.id === payload.id)
    if (!user) return res.status(401).json({ message: 'Invalid token' })
    req.user = user
    next()
  } catch (err) {
    res.status(401).json({ message: 'Invalid token' })
  }
}

// ---------------------------------------------------------------------------
// Routes
// ---------------------------------------------------------------------------

// Register new user
router.post('/api/auth/register', async (req, res) => {
  const { email, password, role } = req.body
  if (!email || !password) {
    return res.status(400).json({ message: 'Email & password required' })
  }
  if (users.some(u => u.email === email)) {
    return res.status(409).json({ message: 'User already exists' })
  }
  const passwordHash = await bcrypt.hash(password, 10)
  const user = { id: generateId(), email, passwordHash, role: role || 'user' }
  users.push(user)
  const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '1h' })
  res.json({ token })
})

// Login
router.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body
  const user = users.find(u => u.email === email)
  if (!user) return res.status(401).json({ message: 'Invalid credentials' })
  const ok = await bcrypt.compare(password, user.passwordHash)
  if (!ok) return res.status(401).json({ message: 'Invalid credentials' })
  const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '1h' })
  res.json({ token })
})

// Get all clones for authenticated user
router.get('/api/clones', authenticate, (req, res) => {
  const userId = req.user.id
  const clones = cloneRecords.filter(cr => cr.userId === userId)
  res.json(clones)
})

// Create a new clone record
router.post('/api/clones', authenticate, (req, res) => {
  const { originalPackage, clonePackage } = req.body
  if (!originalPackage || !clonePackage) {
    return res.status(400).json({ message: 'originalPackage & clonePackage required' })
  }
  const newClone = {
    id: generateId(),
    userId: req.user.id,
    originalPackage,
    clonePackage,
    isHidden: false,
    createdAt: new Date().toISOString()
  }
  cloneRecords.push(newClone)

  // Simulate background cloning process
  setTimeout(() => {
    console.log(`Cloning completed for ${newClone.id}`)
  }, 2000)

  res.status(201).json(newClone)
})

// Delete a clone record
router.delete('/api/clones/:id', authenticate, (req, res) => {
  const cloneId = req.params.id
  const index = cloneRecords.findIndex(cr => cr.id === cloneId && cr.userId === req.user.id)
  if (index === -1) {
    return res.status(404).json({ message: 'Clone not found' })
  }
  cloneRecords.splice(index, 1)
  res.status(204).end()
})

module.exports = router