# Backend

Generated stub for secret-cloner. Run with `node server/index.js` after wiring an Express server.